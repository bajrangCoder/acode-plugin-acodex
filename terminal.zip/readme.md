# Terminal

add support of terminal for acode